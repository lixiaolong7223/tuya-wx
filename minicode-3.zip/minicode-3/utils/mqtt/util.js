export function isWx () {
  return typeof wx !== 'undefined'
}

export function noop() {
}
